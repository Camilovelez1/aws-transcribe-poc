export const SAMPLE_RATE = 44100;
